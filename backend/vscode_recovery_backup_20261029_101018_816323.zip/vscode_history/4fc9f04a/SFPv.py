"""Application entry point for PaperLens."""

from fastapi import FastAPI

from app.controllers.health_controller import router as health_router

app = FastAPI(
    title="PaperLens API",
    description="Document review system with an AI agent harness.",
    version="0.1.0",
)

app.include_router(health_router)