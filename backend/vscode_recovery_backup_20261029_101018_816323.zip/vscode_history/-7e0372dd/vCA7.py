"""PDF storage and text extraction helpers."""

from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path
from uuid import uuid4

import pymupdf as fitz

from fastapi import UploadFile

MAX_FILE_SIZE = 50 * 1024 * 1024
MAX_PAGE_COUNT = 80
CHUNK_SIZE = 1500
CHUNK_OVERLAP = 200
STORAGE_DIR = Path(__file__).resolve().parents[1] / "storage" / "documents"


class PdfProcessingError(ValueError):
    """Indicate that an uploaded file cannot be processed."""


@dataclass(frozen=True)
class ExtractedChunk:
    """Text and source page for one chunk."""

    page_number: int
    text: str


@dataclass(frozen=True)
class ProcessedPdf:
    """Result of storing and extracting an uploaded PDF."""

    storage_key: str
    sha256: str
    page_count: int
    original_filename: str
    chunks: list[ExtractedChunk]
    warning_pages: list[int]


def process_upload(upload: UploadFile) -> ProcessedPdf:
    """Store an upload, validate it, and extract page-local chunks."""
    original_filename = upload.filename or ""
    if Path(original_filename).suffix.lower() != ".pdf":
        raise PdfProcessingError("Only PDF files are supported.")

    STORAGE_DIR.mkdir(parents=True, exist_ok=True)
    storage_key = f"{uuid4()}.pdf"
    target = STORAGE_DIR / storage_key
    digest = sha256()
    total_size = 0

    try:
        with target.open("xb") as output:
            while True:
                block = upload.file.read(1024 * 1024)
                if not block:
                    break
                total_size += len(block)
                if total_size > MAX_FILE_SIZE:
                    raise PdfProcessingError(
                        "PDF file must not exceed 50 MiB."
                    )
                digest.update(block)
                output.write(block)

        if total_size == 0:
            raise PdfProcessingError("The uploaded PDF is empty.")

        return _extract_pdf(
            target=target,
            storage_key=storage_key,
            original_filename=original_filename,
            digest=digest.hexdigest(),
        )
    except PdfProcessingError:
        target.unlink(missing_ok=True)
        raise
    except (fitz.FileDataError, RuntimeError) as exc:
        target.unlink(missing_ok=True)
        raise PdfProcessingError(
            "The uploaded file is not a valid PDF."
        ) from exc
    except Exception:
        target.unlink(missing_ok=True)
        raise


def remove_storage_file(storage_key: str) -> None:
    """Remove a server-owned file after a failed database write."""
    path = STORAGE_DIR / storage_key
    if path.parent == STORAGE_DIR:
        path.unlink(missing_ok=True)


def _extract_pdf(
    target: Path,
    storage_key: str,
    original_filename: str,
    digest: str,
) -> ProcessedPdf:
    """Extract text from a validated PDF without opening a DB transaction."""
    try:
        pdf = fitz.open(stream=target.read_bytes(), filetype="pdf")
    except (fitz.FileDataError, RuntimeError) as exc:
        raise PdfProcessingError(
            "The uploaded file is not a valid PDF."
        ) from exc

    with pdf:
        if pdf.needs_pass:
            raise PdfProcessingError(
                "Password-protected PDFs are not supported."
            )
        page_count = len(pdf)
        if page_count == 0:
            raise PdfProcessingError("The PDF does not contain any pages.")
        if page_count > MAX_PAGE_COUNT:
            raise PdfProcessingError(
                f"PDF files must not exceed {MAX_PAGE_COUNT} pages."
            )

        chunks: list[ExtractedChunk] = []
        warning_pages: list[int] = []
        for page_number, page in enumerate(pdf, start=1):
            try:
                text = page.get_text("text").strip()
            except (RuntimeError, ValueError):
                warning_pages.append(page_number)
                continue
            if not text:
                warning_pages.append(page_number)
                continue
            chunks.extend(
                ExtractedChunk(page_number, chunk)
                for chunk in _split_page_text(text)
            )

        if not chunks:
            raise PdfProcessingError(
                "No extractable text was found; OCR is not supported yet."
            )

    return ProcessedPdf(
        storage_key=storage_key,
        sha256=digest,
        page_count=page_count,
        original_filename=original_filename,
        chunks=chunks,
        warning_pages=warning_pages,
    )


def _split_page_text(text: str) -> list[str]:
    """Split one page into overlapping character-sized chunks."""
    chunks: list[str] = []
    start = 0
    while start < len(text):
        proposed_end = min(start + CHUNK_SIZE, len(text))
        end = proposed_end
        if proposed_end < len(text):
            boundary = max(
                text.rfind("\n\n", start + 1, proposed_end),
                text.rfind("\n", start + 1, proposed_end),
                text.rfind(". ", start + 1, proposed_end),
                text.rfind("? ", start + 1, proposed_end),
                text.rfind("! ", start + 1, proposed_end),
            )
            if boundary > start + CHUNK_SIZE // 2:
                end = boundary + (
                    2
                    if text[boundary : boundary + 2]
                    in ("\n\n", ". ", "? ", "! ")
                    else 1
                )
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        if end >= len(text):
            break
        start = max(start + 1, end - CHUNK_OVERLAP)
    return chunks
