"""HTTP endpoints for documents."""

from typing import Annotated

from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models.document import Document
from app.schemas.document_schema import (
    DocumentCreate,
    DocumentResponse,
)
from app.services import document_service

router = APIRouter(
    prefix="/api/v1/documents",
    tags=["Documents"],
)


@router.post(
    "",
    response_model=DocumentResponse,
    status_code=status.HTTP_201_CREATED,
)
def create_document(
    payload: DocumentCreate,
    db: Annotated[Session, Depends(get_db)],
) -> Document:
    """Create document metadata."""
    return document_service.create_document(
        db=db,
        payload=payload,
    )