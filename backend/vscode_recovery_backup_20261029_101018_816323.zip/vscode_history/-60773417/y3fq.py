"""Business operations for documents."""

from sqlalchemy.orm import Session

from app.models.document import Document
from app.repositories import document_repository
from app.schemas.document_schema import DocumentCreate


def create_document(
    db: Session,
    payload: DocumentCreate,
) -> Document:
    """Create a document in a transaction."""
    with db.begin():
        document = document_repository.create_document(
            db=db,
            title=payload.title,
            description=payload.description,
        )

    return document