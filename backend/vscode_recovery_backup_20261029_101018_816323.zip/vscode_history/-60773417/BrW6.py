"""Business operations for documents."""

from sqlalchemy.orm import Session

from app.models.document import Document
from app.repositories import document_repository
from app.schemas.document_schema import DocumentCreate


def create_document(
    db: Session,
    payload: DocumentCreate,
) -> Document:
    """Create a document in a transaction."""
    with db.begin():
        document = document_repository.create_document(
            db=db,
            title=payload.title,
            description=payload.description,
        )

    return document

class DocumentNotFoundError(LookupError):
    """Indicate that the requested document does not exist."""


def list_documents(
    db: Session,
    offset: int,
    limit: int,
) -> list[Document]:
    """Retrieve a page of documents."""
    return document_repository.list_documents(
        db=db,
        offset=offset,
        limit=limit,
    )


def get_document(
    db: Session,
    document_id: int,
) -> Document:
    """Retrieve a document or raise a not-found error."""
    document = document_repository.get_document(
        db=db,
        document_id=document_id,
    )

    if document is None:
        raise DocumentNotFoundError(
            f"Document {document_id} does not exist."
        )

    return document