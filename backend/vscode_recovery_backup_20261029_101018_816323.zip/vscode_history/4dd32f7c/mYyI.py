"""Database operations for documents."""

from sqlalchemy.orm import Session

from app.models.document import Document


def create_document(
    db: Session,
    title: str,
    description: str | None,
) -> Document:
    """Insert and load a document within the current transaction."""
    document = Document(
        title=title,
        description=description,
    )

    db.add(document)
    db.flush()
    db.refresh(document)

    return document