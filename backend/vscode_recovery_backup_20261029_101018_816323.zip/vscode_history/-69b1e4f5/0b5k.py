"""Sequential whole-document review and bounded hierarchical synthesis."""

from dataclasses import dataclass
import json
import logging
import time
from typing import Any, Callable

from app.adapters.ollama_adapter import OllamaAdapter
from app.models.document import ReviewRunChunk, ReviewRunStage
from app.repositories import review_run_repository
from app.schemas.ai_schema import (
    DocumentFinding,
    DocumentReviewContent,
    DocumentReviewResult,
    ReviewEvidence,
    ReviewSource,
)
from app.services import ai_service

LOGGER = logging.getLogger(__name__)

CONTEXT_LIMIT = 4096
SYNTHESIS_OUTPUT_TOKENS = 768
MAX_SYNTHESIS_ROUNDS = 8

# pylint: disable-next=line-too-long
DOCUMENT_SYNTHESIS_SYSTEM_PROMPT = """Bạn tổng hợp các kết quả review chunk thành
một review tài liệu bằng tiếng Việt. Chỉ trả JSON theo schema đã cung cấp.
summary phải tóm tắt nội dung thực tế được cung cấp, không bình luận về
instruction. key_points phải giữ nguồn chunk_id/page_number. findings chỉ
nêu vấn đề có bằng chứng và có thể rỗng; không tạo lỗi để đủ số lượng.
Chỉ dùng thông tin trong dữ liệu đầu vào, không kết luận toàn tài liệu thiếu
nội dung chỉ vì một chunk không có phần đó. Giữ nguồn và quote chính xác.
Không tiết lộ suy nghĩ nội bộ."""


@dataclass(frozen=True)
class SnapshotContext:
    """A durable chunk snapshot copied out of the ORM session."""

    snapshot_id: int
    chunk_id: int
    chunk_index: int
    page_number: int
    text: str


@dataclass(frozen=True)
class SynthesisNode:
    """One bounded synthesis result and all chunks it covers."""

    content: DocumentReviewContent
    model: str
    sources: list[ReviewSource]
    source_texts: dict[int, str]


def load_snapshot_contexts(
    session_factory: Callable[..., Any],
    run_id: int,
) -> list[SnapshotContext]:
    """Read snapshots in a short transaction before model calls."""
    with session_factory() as db:
        with db.begin():
            snapshots = review_run_repository.list_run_chunks(db, run_id)
            return [_snapshot_context(snapshot) for snapshot in snapshots]


def _snapshot_context(snapshot: ReviewRunChunk) -> SnapshotContext:
    """Copy a snapshot ORM row into plain immutable data."""
    return SnapshotContext(
        snapshot_id=snapshot.id,
        chunk_id=snapshot.source_chunk_id,
        chunk_index=snapshot.chunk_index,
        page_number=snapshot.page_number,
        text=snapshot.text,
    )


# pylint: disable-next=too-many-arguments,too-many-positional-arguments,too-many-locals
def review_document_run(
    session_factory: Callable[..., Any],
    run_id: int,
    document_id: int,
    version_id: int,
    instruction: str,
    adapter: OllamaAdapter,
) -> dict[str, Any]:
    """Review each snapshotted chunk, then synthesize the document."""
    contexts = load_snapshot_contexts(session_factory, run_id)
    if not contexts:
        raise RuntimeError("document review has no chunk snapshots")

    chunk_results: list[dict[str, Any]] = []
    for context in contexts:
        chunk_context = ai_service.ChunkReviewContext(
            document_id=document_id,
            version_id=version_id,
            chunk_id=context.chunk_id,
            page_number=context.page_number,
            text=context.text,
        )
        try:
            result = ai_service.review_chunk_context(
                context=chunk_context,
                adapter=adapter,
                instruction=instruction,
            )
        except Exception as exc:
            with session_factory() as db:
                with db.begin():
                    review_run_repository.fail_chunk(
                        db=db,
                        run_id=run_id,
                        snapshot_id=context.snapshot_id,
                        error_message=str(exc),
                    )
            raise RuntimeError(
                "chunk review failed for "
                f"chunk_id={context.chunk_id}, page={context.page_number}"
            ) from exc
        with session_factory() as db:
            with db.begin():
                review_run_repository.complete_chunk(
                    db=db,
                    run_id=run_id,
                    snapshot_id=context.snapshot_id,
                    result_json=json.dumps(result, ensure_ascii=False),
                )
        chunk_results.append(result)

    with session_factory() as db:
        with db.begin():
            review_run_repository.set_stage(
                db, run_id, ReviewRunStage.SYNTHESIZING
            )

    try:
        final_content, model = _synthesize_document(
            contexts=contexts,
            chunk_results=chunk_results,
            instruction=instruction,
            adapter=adapter,
            run_id=run_id,
        )
    except Exception as exc:
        raise RuntimeError("document synthesis failed") from exc
    final_content = _deduplicate_findings(final_content)
    result = DocumentReviewResult.model_validate(
        {
            **final_content.model_dump(),
            "document_id": document_id,
            "version_id": version_id,
            "model": model,
        }
    )
    return result.model_dump()


# pylint: disable-next=too-many-locals
def _synthesize_document(
    contexts: list[SnapshotContext],
    chunk_results: list[dict[str, Any]],
    instruction: str,
    adapter: OllamaAdapter,
    run_id: int,
) -> tuple[DocumentReviewContent, str]:
    """Run bounded synthesis rounds until one node covers all chunks."""
    source_map = {context.chunk_id: context for context in contexts}
    nodes = [
        SynthesisNode(
            content=_chunk_result_content(result, context),
            model=result["model"],
            sources=[
                ReviewSource(
                    chunk_id=context.chunk_id,
                    page_number=context.page_number,
                )
            ],
            source_texts={context.chunk_id: context.text},
        )
        for context, result in zip(contexts, chunk_results)
    ]
    if len(nodes) != len(contexts):
        raise RuntimeError(
            "document synthesis input is missing a chunk result"
        )

    for round_number in range(1, MAX_SYNTHESIS_ROUNDS + 1):
        nodes = _split_oversized_nodes(nodes, instruction)
        groups = _group_nodes(nodes, instruction)
        if len(nodes) > 1 and len(groups) >= len(nodes):
            raise RuntimeError(
                "document synthesis cannot reduce its context within "
                "4096 tokens"
            )
        LOGGER.info(
            "document_review_synthesis_round_start run_id=%s round=%s "
            "items=%s groups=%s budget_tokens=%s",
            run_id,
            round_number,
            len(nodes),
            len(groups),
            _synthesis_input_budget(instruction),
        )
        next_nodes = []
        for group_number, group in enumerate(groups, start=1):
            input_tokens = sum(
                _estimate_tokens(node_payload(node)) for node in group
            )
            started = time.monotonic()
            LOGGER.info(
                "document_review_synthesis_group_start run_id=%s "
                "round=%s group=%s/%s items=%s estimated_tokens=%s "
                "budget_tokens=%s",
                run_id,
                round_number,
                group_number,
                len(groups),
                len(group),
                input_tokens,
                _synthesis_input_budget(instruction),
            )
            result = _synthesize_group(group, instruction, source_map, adapter)
            LOGGER.info(
                "document_review_synthesis_group_end run_id=%s round=%s "
                "group=%s/%s duration_ms=%s output_items=%s",
                run_id,
                round_number,
                group_number,
                len(groups),
                round((time.monotonic() - started) * 1000),
                len(result.sources),
            )
            next_nodes.append(result)
        if len(next_nodes) == 1:
            final = next_nodes[0]
            expected = set(source_map)
            covered = {source.chunk_id for source in final.sources}
            if covered != expected:
                raise RuntimeError(
                    "document synthesis did not preserve every processed chunk"
                )
            return final.content, final.model
        nodes = next_nodes

    raise RuntimeError(
        "document synthesis exceeded its maximum number of rounds"
    )


def _deduplicate_findings(
    content: DocumentReviewContent,
) -> DocumentReviewContent:
    """Remove only exact duplicate findings without inventing content."""
    unique: list[DocumentFinding] = []
    seen: set[str] = set()
    for finding in content.findings:
        key = json.dumps(
            finding.model_dump(), ensure_ascii=False, sort_keys=True
        )
        if key not in seen:
            seen.add(key)
            unique.append(finding)
    return content.model_copy(update={"findings": unique})


def _chunk_result_content(
    result: dict[str, Any],
    context: SnapshotContext,
) -> DocumentReviewContent:
    """Convert validated chunk review output into synthesis input."""
    findings = [
        DocumentFinding(
            severity=finding["severity"],
            comment=finding["comment"],
            suggestion=finding["suggestion"],
            evidence=[
                ReviewEvidence(
                    chunk_id=context.chunk_id,
                    page_number=context.page_number,
                    quote=finding["quote"],
                )
            ],
        )
        for finding in result["findings"]
    ]
    return DocumentReviewContent(
        summary=result["summary"],
        key_points=[
            {
                "point": result["summary"],
                "sources": [
                    {
                        "chunk_id": context.chunk_id,
                        "page_number": context.page_number,
                    }
                ],
            }
        ],
        findings=findings,
    )


def _group_nodes(
    nodes: list[SynthesisNode],
    instruction: str,
) -> list[list[SynthesisNode]]:
    """Pack nodes conservatively without assuming a fixed char/token ratio."""
    budget = _synthesis_input_budget(instruction)
    groups: list[list[SynthesisNode]] = []
    current: list[SynthesisNode] = []
    current_tokens = 0
    for node in nodes:
        node_tokens = _estimate_tokens(node_payload(node))
        if node_tokens > budget:
            raise RuntimeError(
                "one synthesis item exceeds the 4096-token context budget"
            )
        if current and current_tokens + node_tokens > budget:
            groups.append(current)
            current = []
            current_tokens = 0
        current.append(node)
        current_tokens += node_tokens
    if current:
        groups.append(current)
    return groups


def _split_oversized_nodes(
    nodes: list[SynthesisNode],
    instruction: str,
) -> list[SynthesisNode]:
    """Split a multi-source node before packing it into a request."""
    budget = _synthesis_input_budget(instruction)
    expanded: list[SynthesisNode] = []
    for node in nodes:
        if _estimate_tokens(node_payload(node)) <= budget:
            expanded.append(node)
            continue
        if len(node.sources) < 2:
            estimated_tokens = _estimate_tokens(node_payload(node))
            source_ids = [
                source.chunk_id for source in node.sources
            ]
            raise RuntimeError(
                "Single-source synthesis item exceeds input budget: "
                f"chunk_ids={source_ids}, "
                f"estimated_tokens={estimated_tokens}, "
                f"budget={budget}, "
                f"summary_chars={len(node.content.summary)}, "
                f"key_points={len(node.content.key_points)}, "
                f"findings={len(node.content.findings)}"
            )
        midpoint = len(node.sources) // 2
        for sources in (node.sources[:midpoint], node.sources[midpoint:]):
            part = _project_node_to_sources(node, sources)
            if _estimate_tokens(node_payload(part)) > budget:
                raise RuntimeError(
                    "a partitioned synthesis item still exceeds the "
                    "4096-token context budget"
                )
            expanded.append(part)
    return expanded


def _project_node_to_sources(
    node: SynthesisNode,
    sources: list[ReviewSource],
) -> SynthesisNode:
    """Keep only claims and evidence linked to a source partition."""
    allowed_ids = {source.chunk_id for source in sources}
    key_points = [
        key_point.model_copy(
            update={
                "sources": [
                    source
                    for source in key_point.sources
                    if source.chunk_id in allowed_ids
                ]
            }
        )
        for key_point in node.content.key_points
        if any(source.chunk_id in allowed_ids for source in key_point.sources)
    ]
    findings = [
        finding.model_copy(
            update={
                "evidence": [
                    evidence
                    for evidence in finding.evidence
                    if evidence.chunk_id in allowed_ids
                ]
            }
        )
        for finding in node.content.findings
        if any(
            evidence.chunk_id in allowed_ids for evidence in finding.evidence
        )
    ]
    content = DocumentReviewContent(
        summary=node.content.summary,
        key_points=key_points,
        findings=findings,
    )
    return SynthesisNode(
        content=content,
        model=node.model,
        sources=sources,
        source_texts={},
    )


def _synthesis_input_budget(instruction: str) -> int:
    """Reserve context for instructions, schema, and output."""
    schema = json.dumps(
        DocumentReviewContent.model_json_schema(),
        ensure_ascii=False,
    )
    reserved = _estimate_tokens(
        DOCUMENT_SYNTHESIS_SYSTEM_PROMPT
        + instruction
        + schema
    )
    safety_margin = 128
    budget = (
        CONTEXT_LIMIT
        - reserved
        - SYNTHESIS_OUTPUT_TOKENS
        - safety_margin
    )
    if budget <= 0:
        raise RuntimeError(
            "No synthesis input budget remains: "
            f"context={CONTEXT_LIMIT}, "
            f"reserved_estimate={reserved}, "
            f"output={SYNTHESIS_OUTPUT_TOKENS}, "
            f"safety_margin={safety_margin}"
        )
    return budget


def _estimate_tokens(value: str) -> int:
    """Use a conservative estimate, not one token per four chars."""
    encoded_units = (len(value.encode("utf-8")) + 1) // 2
    word_units = len(value.split()) * 2
    return max(1, encoded_units, word_units)


def node_payload(node: SynthesisNode) -> str:
    """Serialize only compact claims and stable source references."""
    return json.dumps(
        {
            "source_chunks": [source.model_dump() for source in node.sources],
            "review": node.content.model_dump(),
        },
        ensure_ascii=False,
    )


def _synthesize_group(
    group: list[SynthesisNode],
    instruction: str,
    source_map: dict[int, SnapshotContext],
    adapter: OllamaAdapter,
) -> SynthesisNode:
    """Synthesize one context-bounded group and validate its sources."""
    payload = json.dumps(
        {
            "instruction": instruction,
            "items": [json.loads(node_payload(node)) for node in group],
        },
        ensure_ascii=False,
    )
    provider_result = adapter.chat(
        payload,
        num_predict=SYNTHESIS_OUTPUT_TOKENS,
        response_format=DocumentReviewContent.model_json_schema(),
        system_prompt=DOCUMENT_SYNTHESIS_SYSTEM_PROMPT,
        temperature=0,
    )
    if provider_result.get("done") is False or provider_result.get(
        "done_reason"
    ) in {"length", "max_tokens"}:
        raise ai_service.ReviewOutputError(
            "document synthesis output was truncated by the provider"
        )
    content_raw = provider_result.get("content")
    model = provider_result.get("model")
    if not isinstance(content_raw, str) or not isinstance(model, str):
        raise ai_service.ReviewOutputError(
            "document synthesis response is malformed"
        )
    try:
        content = DocumentReviewContent.model_validate(json.loads(content_raw))
    except (json.JSONDecodeError, TypeError, ValueError) as exc:
        raise ai_service.ReviewOutputError(
            "document synthesis output is invalid JSON or schema"
        ) from exc

    allowed_ids = {
        source.chunk_id for node in group for source in node.sources
    }
    _validate_synthesis_sources(content, source_map, allowed_ids)
    sources = [source for node in group for source in node.sources]
    return SynthesisNode(
        content=content,
        model=model,
        sources=sources,
        source_texts={},
    )


def _validate_synthesis_sources(
    content: DocumentReviewContent,
    source_map: dict[int, SnapshotContext],
    allowed_ids: set[int],
) -> None:
    """Ensure model-provided IDs, pages, and quotes belong to this run."""
    for key_point in content.key_points:
        for source in key_point.sources:
            _validate_source(source, source_map, allowed_ids)
    for finding in content.findings:
        for evidence in finding.evidence:
            _validate_source(evidence, source_map, allowed_ids)
            normalized_quote = ai_service.normalize_for_quote(evidence.quote)
            normalized_text = ai_service.normalize_for_quote(
                source_map[evidence.chunk_id].text
            )
            if normalized_quote not in normalized_text:
                raise ai_service.ReviewOutputError(
                    "document synthesis evidence quote is not in its chunk"
                )


def _validate_source(
    source: ReviewSource,
    source_map: dict[int, SnapshotContext],
    allowed_ids: set[int],
) -> None:
    """Validate that a model source points to this run's snapshot."""
    if source.chunk_id not in allowed_ids or source.chunk_id not in source_map:
        raise ai_service.ReviewOutputError(
            "document synthesis referenced a chunk outside this run"
        )
    if source.page_number != source_map[source.chunk_id].page_number:
        raise ai_service.ReviewOutputError(
            "document synthesis referenced the wrong page for a chunk"
        )
